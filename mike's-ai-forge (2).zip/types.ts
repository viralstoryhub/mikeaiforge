// Fix: Add import for React to resolve 'Cannot find namespace React' error.
import React from 'react';

export interface Tool {
  id: string;
  slug: string;
  name: string;
  summary: string;
  websiteUrl: string;
  logoUrl: string;
  pricingModel: 'Freemium' | 'Paid' | 'Free' | 'Usage-based';
  freeTier: boolean;
  rating: number;
  verdict: string;
  pros: string[];
  cons: string[];
  bestFor: string;
  quickstart: string[];
  categories: string[];
  tags: string[];
  affiliateLinkId?: string;
  youtubeReviewId?: string;
}

export interface Utility {
  id: string;
  slug: string;
  name: string;
  description: string;
  path: string;
  icon: string;
}

export interface Workflow {
  id: string;
  slug: string;
  name: string;
  description: string;
  services: string[];
  icon: string;
  deploymentUrl?: string;
}


export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp?: string;
}

export interface AIPersona {
  id: string;
  name: string;
  description: string;
}

export interface User {
  id:string;
  email: string;
  name?: string;
  bio?: string;
  profilePictureUrl?: string;
  savedTools?: string[];
  utilityUsage?: { [slug: string]: number };
  subscriptionTier: 'Free' | 'Pro';
  role: 'User' | 'Admin';
  personas?: AIPersona[];
  createdAt?: string;
  paymentMethod?: {
    last4: string;
    brand: string;
  };
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
}

export type ToastType = 'success' | 'error' | 'info';

export interface ToastMessage {
  id: number;
  message: string;
  type: ToastType;
}

export interface RepurposedContent {
  summary: string;
  keyTakeaways: string[];
  socialPosts: {
    platform: 'LinkedIn' | 'Twitter';
    content: string;
  }[];
}

export interface PresentationFeedback {
  overallScore: number;
  feedback: {
    clarity: string;
    pacing: string;
    fillerWords: string;
    engagement: string;
  };
  suggestions: string[];
  fillerWordCount: { word: string; count: number }[];
}
