
import React from 'react';
import { Link } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import ToolCard from '../components/ToolCard';
import { ToolCardSkeleton } from '../components/Skeletons';

const HomePage: React.FC = () => {
  const { tools, loading } = useData();

  return (
    <div className="space-y-24 md:space-y-32 animate-fade-in-up">
      {/* Hero Section */}
      <section className="text-center py-16 md:py-24 relative">
        <div className="absolute inset-0 -top-32 flex items-center justify-center pointer-events-none">
            <div className="w-[400px] h-[400px] bg-brand-primary/20 rounded-full blur-3xl"></div>
        </div>
        <div className="relative">
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-400">
              <span className="block">I test it on YouTube.</span>
              <span className="block">You deploy it in one click.</span>
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-lg md:text-xl text-light-secondary">
              Welcome to Mike's AI Forge — your hub for battle-tested AI tools, one-click automations, and powerful content utilities.
            </p>
            <div className="mt-10 flex justify-center gap-4 flex-wrap">
              <Link
                to="/utilities"
                className="inline-block bg-brand-primary text-white font-semibold px-8 py-3 rounded-lg shadow-lg hover:opacity-90 transition-opacity"
              >
                Try Free Utilities
              </Link>
              <Link
                to="/tools"
                className="inline-block bg-transparent text-light-primary font-semibold px-8 py-3 rounded-lg border border-border-dark shadow-sm hover:bg-dark-secondary transition-colors"
              >
                Browse AI Tools
              </Link>
            </div>
        </div>
      </section>

      {/* Featured Tools Section */}
      <section>
        <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight text-light-primary sm:text-4xl">Featured AI Tools</h2>
            <p className="mt-3 max-w-2xl mx-auto text-lg text-light-secondary sm:mt-4">
                Curated and tested tools to level up your workflow.
            </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
             Array.from({ length: 3 }).map((_, index) => <ToolCardSkeleton key={index} />)
          ) : (
            tools.slice(0, 3).map((tool, index) => (
              <div key={tool.id} className="animate-fade-in-up" style={{ animationDelay: `${index * 150}ms`}}>
                <ToolCard tool={tool} />
              </div>
            ))
          )}
        </div>
        <div className="text-center mt-10">
            <Link to="/tools" className="text-brand-primary font-semibold hover:underline">
                View All Tools &rarr;
            </Link>
        </div>
      </section>

      {/* Pillars Section */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-dark-secondary p-8 rounded-xl border border-border-dark">
            <h3 className="text-2xl font-bold text-light-primary">Workflow Vault</h3>
            <p className="mt-2 text-light-secondary">One-click deploy workflows from my videos via Make, Zapier, and more.</p>
        </div>
        <div className="bg-dark-secondary p-8 rounded-xl border border-border-dark">
            <h3 className="text-2xl font-bold text-light-primary">Content Automation Studio</h3>
            <p className="mt-2 text-light-secondary">Turn long-form content into shorts, captions, and titles automatically.</p>
        </div>
      </section>
    </div>
  );
};

export default HomePage;