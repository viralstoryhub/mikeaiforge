
import React from 'react';
import { Link } from 'react-router-dom';
import { UTILITIES_DATA } from '../constants';
import { TitleIcon, ListIcon, ClosedCaptionIcon, ImageIcon } from '../components/icons/UtilityIcons';
import { FilmIcon, CameraIcon, MicrophoneIcon, SparklesIcon, WandIcon } from '../components/icons/ExtraIcons';
import { useTiltEffect } from '../hooks/useTiltEffect';
import type { Utility } from '../types';

const iconMap: { [key: string]: React.ComponentType<{ className?: string }> } = {
    TitleIcon,
    ListIcon,
    ClosedCaptionIcon,
    ImageIcon,
    CameraIcon,
    FilmIcon,
    MicrophoneIcon,
    SparklesIcon,
    WandIcon,
};

const UtilityCard: React.FC<{ utility: Utility }> = ({ utility }) => {
  const tiltRef = useTiltEffect<HTMLDivElement>();
  const IconComponent = iconMap[utility.icon];

  return (
    <div ref={tiltRef} className="tilt-card h-full group">
      <Link
        to={utility.path}
        className="block p-6 bg-dark-secondary rounded-lg border border-border-dark group-hover:border-brand-primary/50 transition-colors duration-300 h-full relative overflow-hidden glare-effect"
      >
        <div className="flex items-center space-x-4">
          <div className="flex-shrink-0 bg-dark-primary p-3 rounded-lg border border-border-dark">
            {IconComponent && <IconComponent className="w-6 h-6 text-brand-primary" />}
          </div>
          <div>
            <h3 className="text-lg font-bold text-light-primary group-hover:text-brand-primary">{utility.name}</h3>
            <p className="mt-1 text-sm text-light-secondary">{utility.description}</p>
          </div>
        </div>
      </Link>
    </div>
  );
};


const UtilitiesPage: React.FC = () => {
  return (
    <div className="animate-fade-in-up">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-extrabold tracking-tight text-light-primary sm:text-5xl">Utility Tools</h1>
        <p className="mt-3 max-w-2xl mx-auto text-xl text-light-secondary sm:mt-4">
          Get instant value with free, powerful tools for creators and marketers. No login required for your first few runs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {UTILITIES_DATA.map((utility, index) => (
          <div key={utility.id} className="animate-fade-in-up h-full" style={{ animationDelay: `${index * 100}ms` }}>
            <UtilityCard utility={utility} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default UtilitiesPage;