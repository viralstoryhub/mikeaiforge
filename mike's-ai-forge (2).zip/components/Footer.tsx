
import React, { useState } from 'react';
import FeedbackModal from './FeedbackModal';

const Footer: React.FC = () => {
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);

  return (
    <>
      {isFeedbackModalOpen && (
        <FeedbackModal onClose={() => setIsFeedbackModalOpen(false)} />
      )}
      <footer className="bg-dark-primary border-t border-border-dark">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-light-secondary">
          <p>&copy; {new Date().getFullYear()} Mike's AI Forge. All rights reserved.</p>
          <p className="text-sm mt-1 opacity-75">"I test it on YouTube. You deploy it in one click."</p>
          <div className="mt-4">
             <button
              onClick={() => setIsFeedbackModalOpen(true)}
              className="text-sm text-light-secondary hover:text-brand-primary hover:underline"
            >
              Submit Feedback
            </button>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
