import type { User, AIPersona } from '../types';

// This is a MOCK service to simulate Authentication API calls.
// In a real application, this would make HTTP requests to your backend.

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to get users from localStorage
const getStoredUsers = () => JSON.parse(localStorage.getItem('users') || '{}');

// Helper to save users to localStorage
const setStoredUsers = (users: any) => localStorage.setItem('users', JSON.stringify(users));


// --- User-Facing Functions ---

export const login = async (email: string, password: string): Promise<User> => {
    console.log(`Attempting login for: ${email}`);
    await sleep(1000);

    const storedUsers = getStoredUsers();
    let userData = storedUsers[email];

    const isAdmin = email === 'admin@example.com' && password === 'password';
    if (isAdmin && !userData) {
      // Create admin user if it doesn't exist
      const adminUser: User = { 
        id: '0', 
        email,
        name: 'Admin User',
        role: 'Admin',
        subscriptionTier: 'Pro',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), // Mock creation date
      };
      storedUsers[email] = { ...adminUser, password };
      setStoredUsers(storedUsers);
      userData = storedUsers[email];
    }

    const isNewAdmin = email === 'bri.ar.h.erm.o.us@gmail.com' && password === 'password';
    if (isNewAdmin && !userData) {
      // Create the new admin user if it doesn't exist
      const newAdminUser: User = {
        id: 'admin_brian', // A unique ID
        email,
        name: 'Brian',
        role: 'Admin',
        subscriptionTier: 'Pro',
        createdAt: new Date().toISOString(),
      };
      storedUsers[email] = { ...newAdminUser, password };
      setStoredUsers(storedUsers);
      userData = storedUsers[email];
    }

    const isTestUser = email === 'test@example.com' && password === 'password';
    if (isTestUser && !userData) {
      // Create test user if it doesn't exist
      const testUser: User = { 
        id: '1', 
        email,
        name: 'Test User',
        bio: 'I am a test user for Mike\'s AI Forge.',
        profilePictureUrl: `https://i.pravatar.cc/150?u=1`,
        savedTools: [],
        utilityUsage: {},
        subscriptionTier: 'Free',
        role: 'User',
        personas: [],
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // Mock creation date
      };
      storedUsers[email] = { ...testUser, password };
      setStoredUsers(storedUsers);
      userData = storedUsers[email];
    }
    
    if (userData) {
         // In a real app, you'd verify the password hash here.
         const user: User = { 
            id: userData.id, 
            email: userData.email,
            name: userData.name,
            bio: userData.bio,
            profilePictureUrl: userData.profilePictureUrl,
            savedTools: userData.savedTools || [],
            utilityUsage: userData.utilityUsage || {},
            subscriptionTier: userData.subscriptionTier || 'Free',
            role: userData.role || 'User',
            personas: userData.personas || [],
            createdAt: userData.createdAt,
            paymentMethod: userData.paymentMethod,
            stripeCustomerId: userData.stripeCustomerId,
            stripeSubscriptionId: userData.stripeSubscriptionId,
         };
         localStorage.setItem('user', JSON.stringify(user));
         return user;
    }

    throw new Error('Invalid email or password');
};

export const signup = async (email: string, password: string): Promise<User> => {
    console.log(`Attempting signup for: ${email}`);
    await sleep(1500);

    if (!email || !password) {
        throw new Error('Email and password are required');
    }
    
    const storedUsers = getStoredUsers();
    if (storedUsers[email]) {
        throw new Error('An account with this email already exists.');
    }

    const id = String(Date.now());
    const name = email.split('@')[0].replace(/[^a-zA-Z0-9]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

    const user: User = { 
        id, 
        email,
        name,
        bio: 'New user at Mike\'s AI Forge!',
        profilePictureUrl: `https://i.pravatar.cc/150?u=${id}`, // Default avatar
        savedTools: [],
        utilityUsage: {},
        subscriptionTier: 'Free',
        role: 'User',
        personas: [],
        createdAt: new Date().toISOString(),
    };

    storedUsers[email] = { ...user, password };
    setStoredUsers(storedUsers);
    
    localStorage.setItem('user', JSON.stringify(user));
    return user;
};

export const logout = async (): Promise<void> => {
    console.log('Logging out user.');
    await sleep(500);
    
    try {
        const storedUserJson = localStorage.getItem('user');
        if (storedUserJson) {
            const currentUser: User = JSON.parse(storedUserJson);
            localStorage.removeItem(`chatHistory_${currentUser.id}`);
            console.log(`Cleared chat history for user ${currentUser.id}`);
        }
    } catch (error) {
        console.error("Could not clear user data on logout:", error);
    }
    
    localStorage.removeItem('user');
};

const updateUserInStorage = (user: User): void => {
    localStorage.setItem('user', JSON.stringify(user));
    const storedUsers = getStoredUsers();
    if (storedUsers[user.email]) {
        const { password } = storedUsers[user.email];
        storedUsers[user.email] = { ...user, password };
        setStoredUsers(storedUsers);
    }
};

export const updateUserProfile = async (userId: string, updates: Partial<User>): Promise<User> => {
    console.log(`Updating profile for user ID: ${userId}`, updates);
    await sleep(800);

    const storedUserJson = localStorage.getItem('user');
    if (!storedUserJson) throw new Error("No user is logged in.");
    
    let currentUser = JSON.parse(storedUserJson);
    if (currentUser.id !== userId) throw new Error("Unauthorized to update this profile.");

    const updatedUser = { ...currentUser, ...updates };
    updateUserInStorage(updatedUser);
    return updatedUser;
};

export const toggleSaveTool = async (userId: string, toolId: string): Promise<User> => {
    await sleep(200);

    const storedUserJson = localStorage.getItem('user');
    if (!storedUserJson) throw new Error("No user is logged in.");

    let currentUser = JSON.parse(storedUserJson);
    if (currentUser.id !== userId) throw new Error("Unauthorized action.");

    const updatedSaved = (currentUser.savedTools || []).includes(toolId)
        ? (currentUser.savedTools || []).filter((id: string) => id !== toolId)
        : [...(currentUser.savedTools || []), toolId];

    const updatedUser = { ...currentUser, savedTools: updatedSaved };
    updateUserInStorage(updatedUser);
    return updatedUser;
};

export const recordUtilityUsage = async (userId: string, utilitySlug: string): Promise<User> => {
    await sleep(200);

    const storedUserJson = localStorage.getItem('user');
    if (!storedUserJson) throw new Error("No user is logged in.");

    let currentUser = JSON.parse(storedUserJson);
    if (currentUser.id !== userId) throw new Error("Unauthorized action.");

    const updatedUsage = { ...currentUser.utilityUsage, [utilitySlug]: (currentUser.utilityUsage?.[utilitySlug] || 0) + 1 };
    const updatedUser = { ...currentUser, utilityUsage: updatedUsage };
    updateUserInStorage(updatedUser);
    return updatedUser;
};

export const upgradeSubscription = async (userId: string): Promise<User> => {
    await sleep(2000);

    const storedUserJson = localStorage.getItem('user');
    if (!storedUserJson) throw new Error("No user is logged in.");

    let currentUser = JSON.parse(storedUserJson);
    if (currentUser.id !== userId) throw new Error("Unauthorized action.");

    const updatedUser: User = {
        ...currentUser,
        subscriptionTier: 'Pro',
        stripeCustomerId: `cus_${Date.now()}`,
        stripeSubscriptionId: `sub_${Date.now()}`,
        paymentMethod: { last4: String(Math.floor(1000 + Math.random() * 9000)), brand: 'Visa' },
    };

    updateUserInStorage(updatedUser);
    return updatedUser;
};

// --- Persona Functions ---

export const addPersona = async (userId: string, persona: Omit<AIPersona, 'id'>): Promise<User> => {
    await sleep(300);
    const storedUserJson = localStorage.getItem('user');
    if (!storedUserJson) throw new Error("No user is logged in.");
    
    let currentUser = JSON.parse(storedUserJson);
    if (currentUser.id !== userId) throw new Error("Unauthorized action.");

    const newPersona: AIPersona = { ...persona, id: `persona_${Date.now()}` };
    const updatedPersonas = [...(currentUser.personas || []), newPersona];
    const updatedUser = { ...currentUser, personas: updatedPersonas };

    updateUserInStorage(updatedUser);
    return updatedUser;
};

export const updatePersona = async (userId: string, personaId: string, updates: Partial<AIPersona>): Promise<User> => {
    await sleep(300);
    const storedUserJson = localStorage.getItem('user');
    if (!storedUserJson) throw new Error("No user is logged in.");
    
    let currentUser = JSON.parse(storedUserJson);
    if (currentUser.id !== userId) throw new Error("Unauthorized action.");

    const updatedPersonas = (currentUser.personas || []).map((p: AIPersona) => 
        p.id === personaId ? { ...p, ...updates } : p
    );
    const updatedUser = { ...currentUser, personas: updatedPersonas };

    updateUserInStorage(updatedUser);
    return updatedUser;
};

export const deletePersona = async (userId: string, personaId: string): Promise<User> => {
    await sleep(300);
    const storedUserJson = localStorage.getItem('user');
    if (!storedUserJson) throw new Error("No user is logged in.");
    
    let currentUser = JSON.parse(storedUserJson);
    if (currentUser.id !== userId) throw new Error("Unauthorized action.");

    const updatedPersonas = (currentUser.personas || []).filter((p: AIPersona) => p.id !== personaId);
    const updatedUser = { ...currentUser, personas: updatedPersonas };

    updateUserInStorage(updatedUser);
    return updatedUser;
};


// --- Admin-Only Functions ---

export const getAllUsers = async (): Promise<User[]> => {
    await sleep(500);
    const storedUsers = getStoredUsers();
    // Exclude password field when returning users
    return Object.values(storedUsers).map((u: any) => {
        const { password, ...userWithoutPassword } = u;
        // Ensure every user has a createdAt, mocking for older users
        if (!userWithoutPassword.createdAt) {
          userWithoutPassword.createdAt = new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString();
        }
        return userWithoutPassword as User;
    });
};

export const updateUserAsAdmin = async (userId: string, updates: Partial<User>): Promise<User> => {
    await sleep(500);
    const storedUsers = getStoredUsers();
    const userToUpdate = Object.values(storedUsers).find((u: any) => u.id === userId) as any;

    if (!userToUpdate) throw new Error('User not found');

    const updatedUserRecord = { ...userToUpdate, ...updates };
    storedUsers[userToUpdate.email] = updatedUserRecord;
    setStoredUsers(storedUsers);

    // If the updated user is the currently logged-in user, update their session too
    const loggedInUserJson = localStorage.getItem('user');
    if (loggedInUserJson) {
        const loggedInUser = JSON.parse(loggedInUserJson);
        if (loggedInUser.id === userId) {
            localStorage.setItem('user', JSON.stringify({ ...loggedInUser, ...updates }));
        }
    }

    const { password, ...userWithoutPassword } = updatedUserRecord;
    return userWithoutPassword;
};

export const deleteUserAsAdmin = async (userId: string): Promise<void> => {
    await sleep(500);
    const storedUsers = getStoredUsers();
    const userEmailToDelete = Object.keys(storedUsers).find(email => storedUsers[email].id === userId);

    if (!userEmailToDelete) throw new Error('User not found');

    delete storedUsers[userEmailToDelete];
    setStoredUsers(storedUsers);

    const loggedInUserJson = localStorage.getItem('user');
    if (loggedInUserJson) {
        if (JSON.parse(loggedInUserJson).id === userId) {
            localStorage.removeItem('user'); // Log out user if they delete themselves
        }
    }
};