// A simple mock analytics service that logs to the console.
// In a real application, this would integrate with a service like Google Analytics, Mixpanel, etc.

export const trackEvent = (eventName: string, properties: Record<string, any> = {}): void => {
  console.log(`[Analytics Event]`, {
    event: eventName,
    properties,
    timestamp: new Date().toISOString(),
  });
};
