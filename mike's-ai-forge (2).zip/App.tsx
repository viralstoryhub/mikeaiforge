
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './components/MainLayout';
import HomePage from './pages/HomePage';
import ToolsDirectoryPage from './pages/ToolsDirectoryPage';
import ToolDetailPage from './pages/ToolDetailPage';
import UtilitiesPage from './pages/UtilitiesPage';
import TitlesHooksGenerator from './pages/utility/TitlesHooksGenerator';
import YoutubeChaptersGenerator from './pages/utility/YoutubeChaptersGenerator';
import CaptionFormatter from './pages/utility/CaptionFormatter';
import ThumbnailPromptGenerator from './pages/utility/ThumbnailPromptGenerator';
import VideoClipGenerator from './pages/utility/VideoClipGenerator';
import ThumbnailTester from './pages/utility/ThumbnailTester';
import VideoAudioTranscriber from './pages/utility/VideoAudioTranscriber';
import ContentRepurposer from './pages/utility/ContentRepurposer';
import ChatPage from './pages/ChatPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import ScrollToTop from './components/ScrollToTop';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import DashboardPage from './pages/DashboardPage';
import { ToastProvider } from './contexts/ToastContext';
import ToastContainer from './components/ToastContainer';
import WorkflowVaultPage from './pages/WorkflowVaultPage';
import ContentStudioPage from './pages/ContentStudioPage';
import { DataProvider } from './contexts/DataContext';
import AIImageEditor from './pages/utility/AIImageEditor';
import ThumbnailGenerator from './pages/utility/ThumbnailGenerator';
import { CommandPaletteProvider } from './contexts/CommandPaletteContext';
import PresentationCoach from './pages/utility/PresentationCoach';

// Admin Imports
import AdminRoute from './components/AdminRoute';
import AdminLayout from './components/admin/AdminLayout';
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import AdminUsersPage from './pages/admin/AdminUsersPage';
import AdminToolsPage from './pages/admin/AdminToolsPage';
import AdminWorkflowsPage from './pages/admin/AdminWorkflowsPage';
import AdminAnalyticsPage from './pages/admin/AdminAnalyticsPage';

const App: React.FC = () => {
  return (
    <AuthProvider>
      <ToastProvider>
        <HashRouter>
          <ScrollToTop />
          <CommandPaletteProvider>
            <Routes>
              {/* Admin Section */}
              <Route 
                path="/admin/*"
                element={
                  <DataProvider>
                    <AdminRoute>
                      <AdminLayout>
                        <Routes>
                          <Route path="dashboard" element={<AdminDashboardPage />} />
                          <Route path="analytics" element={<AdminAnalyticsPage />} />
                          <Route path="users" element={<AdminUsersPage />} />
                          <Route path="tools" element={<AdminToolsPage />} />
                          <Route path="workflows" element={<AdminWorkflowsPage />} />
                          <Route path="*" element={<Navigate to="dashboard" />} />
                        </Routes>
                      </AdminLayout>
                    </AdminRoute>
                  </DataProvider>
                }
              />
              
              {/* Public Section */}
              <Route 
                path="/*" 
                element={
                  <DataProvider>
                    <Routes>
                      <Route element={<MainLayout />}>
                        <Route path="/" element={<HomePage />} />
                        <Route path="/tools" element={<ToolsDirectoryPage />} />
                        <Route path="/tools/:slug" element={<ToolDetailPage />} />
                        <Route path="/utilities" element={<UtilitiesPage />} />
                        <Route path="/utilities/titles-hooks-generator" element={<TitlesHooksGenerator />} />
                        <Route path="/utilities/youtube-chapters-summary" element={<YoutubeChaptersGenerator />} />
                        <Route path="/utilities/captions-formatter" element={<CaptionFormatter />} />
                        <Route path="/utilities/thumbnail-prompt-generator" element={<ThumbnailPromptGenerator />} />
                        <Route path="/utilities/thumbnail-generator" element={<ThumbnailGenerator />} />
                        <Route path="/utilities/thumbnail-tester" element={<ThumbnailTester />} />
                        <Route path="/utilities/video-clip-generator" element={<VideoClipGenerator />} />
                        <Route path="/utilities/video-audio-transcriber" element={<VideoAudioTranscriber />} />
                        <Route path="/utilities/content-repurposer" element={<ContentRepurposer />} />
                        <Route path="/utilities/ai-image-editor" element={<AIImageEditor />} />
                        <Route path="/utilities/presentation-coach" element={<ProtectedRoute><PresentationCoach /></ProtectedRoute>} />
                        <Route path="/workflows" element={<WorkflowVaultPage />} />
                        <Route path="/content-studio" element={<ContentStudioPage />} />
                        <Route 
                          path="/chat" 
                          element={<ProtectedRoute><ChatPage /></ProtectedRoute>} 
                        />
                        <Route 
                          path="/dashboard" 
                          element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} 
                        />
                        <Route path="/login" element={<LoginPage />} />
                        <Route path="/signup" element={<SignupPage />} />
                        <Route path="*" element={<Navigate to="/" />} />
                      </Route>
                    </Routes>
                  </DataProvider>
                } 
              />
            </Routes>
          </CommandPaletteProvider>
          <ToastContainer />
        </HashRouter>
      </ToastProvider>
    </AuthProvider>
  );
};

export default App;
